<?php
$vendor_path = dirname(__FILE__).'/vendor';
include $vendor_path.'/eazy-jsonrpc/src/BaseJsonRpcServer.php';
?>
