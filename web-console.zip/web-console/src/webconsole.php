<?php
$path = dirname(__FILE__);
include $path.'/webconsole.settings.php';
include $path.'/webconsole.includes.php';
include $path.'/webconsole.main.php';
?>
