<?php
    // Redirect to latest release (for development)
    header("Location: webconsole.php");
    exit();
?>
